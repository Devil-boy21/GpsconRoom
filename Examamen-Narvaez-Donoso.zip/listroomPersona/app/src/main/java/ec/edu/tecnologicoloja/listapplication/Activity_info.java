package ec.edu.tecnologicoloja.listapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import ec.edu.tecnologicoloja.listapplication.database.Persona;

public class Activity_info extends AppCompatActivity implements View.OnClickListener {

    private Persona objeto;
    private TextView nombre,apellido,direccion;
    private ImageView imagen,imagenDato;
    private ImageButton imagmapa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);


        //creamos el objeto de tipo persona
        objeto = (Persona) getIntent().getSerializableExtra("id");

        //inicializamos los texView para mostrar los datos
        nombre = findViewById(R.id.txtnombre);
        apellido = findViewById(R.id.txtapellido);
        direccion = findViewById(R.id.txtdireccion);
       // imagen = findViewById(R.id.img);
        imagenDato= findViewById(R.id.imgdato);
        imagmapa = (ImageButton) findViewById(R.id.iraMapa);
        imagmapa.setOnClickListener(this);

        //llamamos a los atributos de tipo objeto
        nombre.setText(objeto.getNombre());
        apellido.setText(objeto.getApellido());
        direccion.setText(objeto.getDireccion());

        //llamamos a la imagen del dato
        Glide.with(this).load("http://i.imgur.com/DvpvklR.png").into(imagenDato);

    }

    //para ir al mapa
    @Override
    public void onClick(View v) {
        if (v==imagmapa){
            Intent intent = new Intent(Activity_info.this, MapsActivity.class);
            intent.putExtra("longitud",apellido.getText());
            intent.putExtra("latitud",direccion.getText());
            startActivity(intent);

        }

    }
}