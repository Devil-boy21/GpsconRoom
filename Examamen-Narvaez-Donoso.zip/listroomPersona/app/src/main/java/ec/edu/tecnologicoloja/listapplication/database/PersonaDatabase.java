package ec.edu.tecnologicoloja.listapplication.database;


import androidx.room.Database;
import androidx.room.RoomDatabase;
// la base de datos de Persona
@Database(entities = {Persona.class},version = 2)
public abstract class PersonaDatabase extends RoomDatabase {

    public abstract PersonaDao getPersonaDao();

}
